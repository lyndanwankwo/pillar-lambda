const { RatingDelegates } = require("./ratingdelegates");
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

exports.handler = async (event) => {


    // const testBody = {
    //     "operation": "premium",
    //     "policy": 
    //    {
    //     "locator": 100000000,
    //     "guaranteedRate": "2.5",
    //     "guaranteedTerm": "3",
    //     "guaranteedRenewalRate": "1",
    //     "freeWithdrawalAmountLeft": "10000",
    //     "freeWithdrawalPercent": "10",
    //     "premium": "100000",
    //     "startingAccountValue": "100000",
    //     "endingAccountValue": "100000",
    //     "surrenderRate": "9",
    //     "lastTransactionDate": "2020-12-12",
    //     "withdrawalAmount": "2000"
    //   }
    // }
    const rating = new RatingDelegates(event.body); //JSON.stringify(testBody)
    var returnObject = {};
    let functionType = JSON.parse(event.body).operation;
    console.log(functionType)
    if (functionType === "quoteAccount") {
        returnObject["projectedValue"] = rating.quoteAccount();
        returnObject["interestEarned"] = rating.interestEarned();
        returnObject["interestRate"] = rating.interestRate();

        const response = {
            statusCode: 200,
            body: JSON.stringify(returnObject),
        };
        return response;
    }
    else if (functionType === "checkAccountBalance")
    {
        returnObject["withdrawalAmount"] = rating._withdrawalAmount();
        returnObject["surrenderCharges"] = rating.surrenderCharge();
        returnObject["amountDisbursed"] = rating.disbursedAmount();
        returnObject["startingAccountValue"] = rating.currentAccountValue();
        returnObject["endingAccountValue"] = rating.newEndingValue();
        returnObject["freeWithdrawalAmountLeft"] = rating.freeValueLeft();
        returnObject["interestEarned"] = rating.interestEarned();
        returnObject["interestYTD"] = rating.interestYTD();
        returnObject["lastTransactionDate"] = new Date();
        returnObject["interestRate"] = rating.interestRate();
        const response = {
            statusCode: 200,
            body: JSON.stringify(returnObject),
        };
        return response;
    }
    else {
        returnObject["withdrawalAmount"] = rating._withdrawalAmount();
        returnObject["surrenderCharges"] = rating.surrenderCharge();
        returnObject["amountDisbursed"] = rating.disbursedAmount();
        returnObject["startingAccountValue"] = rating.currentAccountValue();
        returnObject["endingAccountValue"] = rating.newEndingValue();
        returnObject["freeWithdrawalAmountLeft"] = rating.freeValueLeft();
        returnObject["interestEarned"] = rating.interestEarned();
        returnObject["interestYTD"] = rating.interestYTD();
        returnObject["lastTransactionDate"] = new Date();
        returnObject["interestRate"] = rating.interestRate();
        var authBody = JSON.stringify({
            "hostName": "lnwankwo-socotra-pillar.co.sandbox.socotra.com",
            "username": "alice.lee",
            "password": "socotra"
        });
        var authOptions = {
            method: 'POST',
            body: authBody,
            headers: { 'Content-Type': 'application/json' }
        };
        const url = "https://api.sandbox.socotra.com";
        const authUrl = "/account/authenticate";
        const auxUrl = "/auxData/" + rating.policy.locator.toString();

        async function postAuxData() {
            const auth = await fetch(url + authUrl, authOptions).then(response => response.json());

            for (const [key, value] of Object.entries(returnObject)) {
                var raw = JSON.stringify({
                    auxData: {
                        key: key,
                        value: value,
                        uiType: "normal"
                    }
                });
                var setAuxOptions = {
                    method: 'PUT',
                    body: raw,
                    headers: { 'Authorization': auth.authorizationToken, 'Content-Type': 'application/json', 'Accept': 'application/json', }
                }
                const aux = await fetch(url + auxUrl, setAuxOptions).then(response => response.text())
                    .catch(err => console.log(err));
            }
        }
        postAuxData();

        const response = {
            statusCode: 200,
            body: JSON.stringify(returnObject),
        };
        return response;
        }

};
